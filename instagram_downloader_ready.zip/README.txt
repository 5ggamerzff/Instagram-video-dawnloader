README - Instagram Video Downloader (ready-to-run)
--------------------------------------------------

What's included:
- A single-container Node.js project that serves a small static UI and an API endpoint /api/fetch?url=... 
  The server uses Playwright to load the Instagram page and extract an Open Graph direct video URL where possible.
- Files: server.js, public/index.html, public/app.js, package.json, Dockerfile

Quick local run (requires Docker):
1) Build the image:
   docker build -t insta-downloader:latest /path/to/project

2) Run the container:
   docker run -p 3000:3000 --shm-size=1g insta-downloader:latest

3) Open http://localhost:3000 in your browser and paste an Instagram post/reel URL.

Notes & warnings:
- Playwright and browser binaries add significant size (~200–400MB). First build may take a while.
- Instagram frequently updates; some posts (private accounts) cannot be downloaded.
- Respect copyright and Instagram Terms of Service. Use only for content you are allowed to download.
- If you cannot run Docker or want me to produce a simplified non-Playwright version, tell me and I will provide it.

If you want, I can now:
- Provide a step-by-step video or screenshots for running the Docker commands.
- Create a small VPS-ready deployment script (DigitalOcean Docker droplet / systemd service).
- Or, produce a GitHub-ready repository structure (I can zip it — already created here).

Enjoy!
