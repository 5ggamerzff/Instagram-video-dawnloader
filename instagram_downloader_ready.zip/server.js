const express = require('express');
const cors = require('cors');
const cheerio = require('cheerio');
const fetch = require('node-fetch');
const { chromium } = require('playwright');

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static('public'));

app.get('/api/health', (req, res) => res.json({ ok: true }));

app.get('/api/fetch', async (req, res) => {
  const url = req.query.url;
  if (!url) return res.status(400).json({ error: 'Missing url parameter' });
  if (!/instagram\\.com\\/(p|reel|tv)\\//i.test(url)) {
    return res.status(400).json({ error: 'URL does not look like an Instagram post (expected /p/ or /reel/ or /tv/)' });
  }

  let browser;
  try {
    browser = await chromium.launch({ args: ['--no-sandbox', '--disable-setuid-sandbox'] });
    const context = await browser.newContext({ userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0 Safari/537.36' });
    const page = await context.newPage();
    await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 30000 });
    const html = await page.content();
    const $ = cheerio.load(html);

    let videoUrl = $('meta[property="og:video"]').attr('content') || $('meta[name="og:video"]')?.attr('content');
    let thumbnail = $('meta[property="og:image"]').attr('content') || $('meta[name="og:image:secure_url"]').attr('content');

    if (!videoUrl) {
      const ld = $('script[type="application/ld+json"]').map((i, el) => $(el).html()).get().join('\\n');
      try {
        const parsed = JSON.parse(ld);
        if (parsed && parsed.video && parsed.video.contentUrl) {
          videoUrl = parsed.video.contentUrl;
        }
      } catch (e) {}
    }

    if (!videoUrl) {
      videoUrl = $('meta[property="og:video:secure_url"]').attr('content') || $('meta[name="twitter:player:stream"]')?.attr('content');
    }

    if (!videoUrl) {
      const sharedData = await page.evaluate(() => {
        try { return window._sharedData || null; } catch (e) { return null; }
      });
      if (sharedData) {
        try {
          const entry = JSON.stringify(sharedData);
          const matches = entry.match(/https:\\\\/\\\\/s?cdn\\.instagram\\.com\\\\/[^\\\"']+/g);
          if (matches && matches.length) videoUrl = matches[0].replace(/\\\\\\\\/g, '');
        } catch (e) {}
      }
    }

    await browser.close();

    if (!videoUrl) {
      return res.status(404).json({ error: 'Could not find a direct video URL. Instagram may block scraping or the post may be an image only.' });
    }

    return res.json({ videoUrl, thumbnail: thumbnail || null, type: 'video' });
  } catch (err) {
    if (browser) await browser.close();
    console.error('Fetch error', err && err.message);
    return res.status(500).json({ error: 'Server error fetching Instagram post', details: err && err.message });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server listening on port ${PORT}`));
