document.getElementById('theForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const url = document.getElementById('url').value.trim();
  const result = document.getElementById('result');
  result.innerHTML = '';
  if (!url) return result.innerHTML = '<div style="color:#b91c1c">Please paste a URL.</div>';
  const btn = document.getElementById('fetchBtn');
  btn.disabled = true;
  btn.textContent = 'Fetching...';
  try {
    const res = await fetch(`/api/fetch?url=${encodeURIComponent(url)}`);
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Unknown error');
    const html = [];
    if (data.thumbnail) html.push(`<img src="${data.thumbnail}" alt="thumbnail" />`);
    html.push(`<p><strong>Type:</strong> ${data.type}</p>`);
    html.push(`<p><strong>Video URL:</strong> <a href="${data.videoUrl}" target="_blank" rel="noreferrer">Open</a></p>`);
    html.push(`<p><button id="dlBtn">Download Video</button></p>`);
    result.innerHTML = html.join('');
    document.getElementById('dlBtn').addEventListener('click', () => {
      const a = document.createElement('a');
      a.href = data.videoUrl;
      a.download = `instagram_${Date.now()}.mp4`;
      document.body.appendChild(a);
      a.click();
      a.remove();
    });
  } catch (err) {
    result.innerHTML = `<div style="color:#b91c1c">${err.message}</div>`;
  } finally {
    btn.disabled = false;
    btn.textContent = 'Fetch Video';
  }
});

document.getElementById('clearBtn').addEventListener('click', ()=>{
  document.getElementById('url').value='';
  document.getElementById('result').innerHTML='';
});
